import unittest
from fastapi.testclient import TestClient
from main import app
from schemas import BookCreate, ReviewCreate

client = TestClient(app)

class TestBookAPI(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # This will run once for the entire test case and store the book ID
        response = client.post("/books/", json={
            "title": "Example Book",
            "author": "Author Name",
            "genre": "Fiction",
            "year_published": 2023,
            "summary": "A test book summary."
        })
        cls.book_id = response.json()["id"]

    def test_get_books(self):
        response = client.get("/books/")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIsInstance(data, list)

    def test_get_book_by_id(self):
        response = client.get(f"/books/{self.book_id}")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["id"], self.book_id)

    def test_update_book(self):
        response = client.put(f"/books/{self.book_id}", json={
            "title": "Updated Book",
            "author": "Updated Author",
            "genre": "Non-Fiction",
            "year_published": 2022,
            "summary": "Updated summary."
        })
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["title"], "Updated Book")


    def test_create_review(self):
        response = client.post(f"/books/{self.book_id}/reviews", json={
            "user_id": 1,
            "review_text": "Great book!",
            "rating": 5
        })
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["review_text"], "Great book!")

    def test_get_reviews(self):
        response = client.get(f"/books/{self.book_id}/reviews")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIsInstance(data, list)

    # def test_get_book_summary(self):
    #     response = client.get(f"/books/{self.book_id}/summary")
    #     self.assertEqual(response.status_code, 200)
    #     data = response.json()
    #     self.assertIn("summary", data)
    #     self.assertIn("aggregated_rating", data)

    # def test_get_recommendations(self):
    #     response = client.get("/recommendations")
    #     self.assertEqual(response.status_code, 200)
    #     data = response.json()
    #     self.assertIsInstance(data, list)

    # def test_generate_summary(self):
    #     response = client.post("/generate-summary", json={
    #         "content": "This is an example content for generating a summary."
    #     })
    #     self.assertEqual(response.status_code, 200)
    #     data = response.json()
        # self.assertIn("summary", data)
   
    def test_delete_book(self):
        response = client.delete(f"/books/{self.book_id}")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"detail": "Book deleted"})

if __name__ == '__main__':
    unittest.main()
